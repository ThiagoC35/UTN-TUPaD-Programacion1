#Ejercicio 1
def factorial(n):
        # Caso base
        if n == 0 or n == 1:
            return 1
        # Caso recursivo
        else:
            return n * factorial(n - 1)

# Programa principal
try:
    limite = int(input("Ingrese un número entero no negativo: "))
    if limite < 0:
        print("El número debe ser no negativo.")
    else:
        print(f"\nFactoriales desde 1 hasta {limite}:")
        for i in range(1, limite + 1):
            print(f"Factorial de {i} = {factorial(i)}")
except ValueError:
    print("Por favor, ingrese un número entero válido.")

#Ejercicio 2
def fibonacci(n):
    # Casos base
    if n == 0:
        return 0
    elif n == 1:
        return 1
    # Caso recursivo
    else:
        return fibonacci(n - 1) + fibonacci(n - 2)

# Programa principal
try:
    posicion = int(input("Ingrese la posición hasta la cual desea ver la sucesión de Fibonacci: "))
    if posicion < 0:
        print("La posición debe ser un número entero no negativo.")
    else:
        print(f"\nSucesión de Fibonacci hasta la posición {posicion}:")
        for i in range(posicion + 1):
            print(f"Posición {i}: {fibonacci(i)}")
except ValueError:
    print("Por favor, ingrese un número entero válido.")

#Ejercicio 3
def potencia(base, exponente):
    # Caso base
    if exponente == 0:
        return 1
    # Caso recursivo
    else:
        return base * potencia(base, exponente - 1)

# Programa principal
try:
    b = int(input("Ingrese la base (n): "))
    e = int(input("Ingrese el exponente (m, entero no negativo): "))
    
    if e < 0:
        print("El exponente debe ser un entero no negativo.")
    else:
        resultado = potencia(b, e)
        print(f"{b} elevado a la {e} es: {resultado}")
except ValueError:
    print("Por favor, ingrese valores numéricos válidos.")

#Ejercicio 4
def decimal_a_binario(n):
    # Caso base
    if n == 0:
        return ""
    # Caso recursivo: se divide por 2 y se concatena el resto al final
    else:
        return decimal_a_binario(n // 2) + str(n % 2)

# Programa principal
try:
    numero = int(input("Ingrese un número entero positivo en base decimal: "))
    if numero < 0:
        print("El número debe ser positivo.")
    elif numero == 0:
        print("El equivalente en binario es: 0")
    else:
        binario = decimal_a_binario(numero)
        print(f"El número {numero} en binario es: {binario}")
except ValueError:
    print("Por favor, ingrese un número entero válido.")

#Ejercicio 5
def es_palindromo(palabra):
    # Caso base 1: si la cadena tiene 0 o 1 caracter, es palíndromo
    if len(palabra) <= 1:
        return True
    # Caso base 2: si el primer y último caracter no coinciden, no es palíndromo
    if palabra[0] != palabra[-1]:
        return False
    # Caso recursivo: evaluamos la subcadena sin el primer y último caracter
    return es_palindromo(palabra[1:-1])

# Programa principal
texto = input("Ingrese una palabra (sin espacios ni tildes): ").strip().lower()
if es_palindromo(texto):
    print(f"'{texto}' SÍ es un palíndromo.")
else:
    print(f"'{texto}' NO es un palíndromo.")

#Ejercicio 6
def suma_digitos(n):
    # Caso base: si el número tiene un solo dígito
    if n < 10:
        return n
    # Caso recursivo: último dígito (n % 10) + la suma del resto del número (n // 10)
    else:
        return (n % 10) + suma_digitos(n // 10)

# Programa principal
try:
    num = int(input("Ingrese un número entero positivo: "))
    if num < 0:
        print("El número debe ser positivo.")
    else:
        resultado = suma_digitos(num)
        print(f"La suma de los dígitos de {num} es: {resultado}")
except ValueError:
    print("Por favor, ingrese un número entero válido.")

#Ejercicio 7
def contar_bloques(n):
    # Caso base: si hay 1 solo bloque en la base, se necesita 1 bloque en total
    if n == 1:
        return 1
    # Caso recursivo: bloques del nivel actual (n) más los bloques de la pirámide restante (n - 1)
    else:
        return n + contar_bloques(n - 1)

# Programa principal
try:
    nivel_bajo = int(input("Ingrese la cantidad de bloques en el nivel más bajo: "))
    if nivel_bajo < 1:
        print("La cantidad de bloques debe ser al menos 1.")
    else:
        total = contar_bloques(nivel_bajo)
        print(f"Total de bloques necesarios para la pirámide: {total}")
except ValueError:
    print("Por favor, ingrese un número entero válido.")


#Ejercicio 8
def contar_digito(numero, digito):
    # Caso base: cuando el número se reduce a 0
    if numero == 0:
        return 0
    
    # Comprobamos si el último dígito coincide
    coincidencia = 1 if (numero % 10) == digito else 0
    
    # Caso recursivo: sumamos la coincidencia y avanzamos al siguiente dígito (numero // 10)
    return coincidencia + contar_digito(numero // 10, digito)

# Programa principal
try:
    num = int(input("Ingrese un número entero positivo: "))
    dig = int(input("Ingrese el dígito a buscar (0-9): "))
    
    if num < 0 or dig < 0 or dig > 9:
        print("Datos inválidos. Asegúrese de que el número sea positivo y el dígito esté entre 0 y 9.")
    else:
        apariciones = contar_digito(num, dig)
        print(f"El dígito {dig} aparece {apariciones} veces en el número {num}.")
except ValueError:
    print("Por favor, ingrese valores numéricos válidos.")